package com.example;

public class Animal {
    protected String name;
    
    public Animal(String name) {
        this.name = name;
    }
    
    public void makeSound() {
        System.out.println("The animal makes a sound.");
    }
    
    public void sleep() {
        System.out.println("The animal is sleeping.");
    }
}

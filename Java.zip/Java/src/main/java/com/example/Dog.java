package com.example;

public class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }
    
    public void makeSound() {
        System.out.println("The dog barks.");
    }
    
    public void sleep(int hours) {
        System.out.println("The dog sleeps for " + hours + " hours.");
    }
}
